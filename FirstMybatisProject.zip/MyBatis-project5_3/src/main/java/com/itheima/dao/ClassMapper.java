package com.itheima.dao;

import com.itheima.pojo.CClass;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

public interface ClassMapper {
    @Select("select * from c_class where classname=#{classname}")
    @Results({@Result(id=true,column = "id",property = "id"),
            @Result(column = "classname",property = "classname"),
            @Result(column = "id",property = "studentList",
                    many = @Many(select = "com.itheima.dao.StudentMapper.selectStudentById2"))
    })
    CClass selectStudentByclassname(String s);
}
