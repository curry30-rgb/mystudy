package XmlMapper;

import com.itheima.pojo.CClass;
import com.itheima.pojo.Student;
import com.itheima.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class MybatisTest {
    @Test
    public void findStudentByIdTest(){
        SqlSession sqlSession= MybatisUtils.openSession();
        Student student = sqlSession.selectOne("com.itheima.pojo.Student.findStudentById", 4);
        System.out.println(student);
    }

    @Test
    public void updateByIdTest(){
        SqlSession sqlSession= MybatisUtils.openSession();

        Student student=new Student();
        student.setName("李雷");
        student.setAge(29);
        student.setId(4);

        int updateNum = sqlSession.update("com.itheima.pojo.Student.updateById", student);
        if(updateNum>0){
            System.out.println("成功修改"+updateNum+"条数据");
        }else{
            System.out.println("修改数据失败");
        }

        sqlSession.commit();
        sqlSession.close();
    }

    @Test
    public void findStudentByclassnameTest(){
        SqlSession sqlSession= MybatisUtils.openSession();

        CClass cClass=sqlSession.selectOne("com.itheima.pojo.CClass.findStudentByclassname","二班");

        System.out.println(cClass);
        sqlSession.close();
    }
}
