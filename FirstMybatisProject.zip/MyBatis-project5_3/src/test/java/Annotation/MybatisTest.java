package Annotation;

import com.itheima.dao.ClassMapper;
import com.itheima.dao.StudentMapper;
import com.itheima.pojo.CClass;
import com.itheima.pojo.Student;
import com.itheima.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class MybatisTest {
    @Test
    public void selectStudentByIdTest(){
        SqlSession sqlSession= MybatisUtils.openSession();
        StudentMapper mapper=sqlSession.getMapper(StudentMapper.class);
        Student student=mapper.selectStudentById(2);
        System.out.println(student.toString());
        sqlSession.close();
    }

    @Test
    public void UpdateStudentTest(){
        SqlSession sqlSession= MybatisUtils.openSession();

        Student student=new Student();
        student.setName("高科");
        student.setAge(29);
        student.setId(4);

        StudentMapper mapper=sqlSession.getMapper(StudentMapper.class);
        int num=mapper.UpdateStudent(student);
        if(num>0){
            System.out.println("成功更新"+num+"条数据");
        }else{
            System.out.println("更新数据失败");
        }
        System.out.println(student.toString());
        sqlSession.commit();
        sqlSession.close();
    }

    @Test
    public void selectStudentByclassnameTest(){
        SqlSession sqlSession= MybatisUtils.openSession();
        ClassMapper mapper=sqlSession.getMapper(ClassMapper.class);

        CClass cClass=mapper.selectStudentByclassname("二班");
        System.out.println(cClass.toString());
        sqlSession.close();
    }
}
