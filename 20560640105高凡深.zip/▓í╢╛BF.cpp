#include<iostream>
#include<fstream>
#include<iomanip>
using namespace std;
int VirusBF(string S, string T) {
	int i = 0, j = 0;
	int x, y;
	int m;
	S = S + S;
	for (m = 0; m < S.length() / 2; m++) {
		i = m;
		int n = i;
		while (i < S.length() - 1 && j < T.length()) {
			if (S[i] == T[j]) {
				i++;
				j++;
				if ((i - n) >= (S.length() / 2)) {
					return 1;
				}
			}
			else {
				j = j - i + m + 1;
				i = m;
			}
		}
		x = i;
		y = j;
		j = 0;
		if (x >= S.length() / 2) {
			break;
		}
	}
	if (m == S.length() / 2) {
		return -1;
	}
}

int main() {
	string virus;
	string person;
	ifstream infile;
	ofstream outfile;
	infile.open("����.txt", ios::in);
	outfile.open("���.txt", ios::out);
	while (!infile.eof()) {
		infile >> virus >> person;
		int a = VirusBF(virus, person);
		if (a == -1) {
			outfile << virus << "	" << person <<setw(5)<< " " << "NO" << endl;
		}
		else if(a==1) {
			outfile << virus << "	" << person << setw(5) << " " << "YES" << endl;
		}
	}
	cout << "����������򿪡����.txt���鿴�����" << endl;
	infile.close();
	outfile.close();
	return 0;
}