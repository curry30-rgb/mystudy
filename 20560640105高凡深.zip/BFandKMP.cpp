#include<iostream>
using namespace std;

int BF(string S,string T) {
	int i = 0, j = 0;
	while (i < S.length() && j < T.length()) {
		if (S[i] == T[j]) {
			i++;
			j++;
		}
		else {
			j = j - i + 1;
			i = 0;
		}
	}
	if (i >= S.length()) {
		return j-S.length();
	}
	else if(j>=T.length()){
		return -1;
	}
}

int KMP(string S, string T) {
	int next[20];
	void get_next(string virus, int next[]);
	get_next(S, next);
	int i = 0, j = 0;
	while (i < S.length() && j < T.length()) {
		if (j==-1 || S[i] == T[j]) {
			i++;
			j++;
		}
		else {
			j = next[j];
		}
	}
	if (j >= S.length()) {
		return 1;
	}
	else {
		return 0;
	}
}

void get_next(string virus,int next[]) {
	int j, k;
	next[0] = -1;
	j = 0;
	k = -1;
	while (j < virus.length()-1) {
		if (k==-1 || virus[j] == virus[k]) {
			++k;
			++j;
			next[j] = k;
		}
		else {
			k=next[k];
		}
	}
}

int main() {
	string vir = "ababcbaabbab";
	string per = "aafbababababbbabbbbbaba";
	
	int a = KMP(vir,per);
	if (a == -1) {
		cout << "ƥ��ʧ��!";
	}
	else {
		cout << "ƥ��ɹ�!";
	}
	return 0;
}