"""先求出由这四个组成的没有重复的数"""
from math import sqrt

list = [1, 2, 3, 4]
list2 = []
for i in list:
    for j in list:
        if i == j:
            continue
        for k in list:
            if (i == k) or (j == k):
                continue
            for n in list:
                if (i == n) or (j == n) or (k == n):
                    continue
                num = 1000 * i + 100 * j + 10 * k + n
                list2.append(num)
# print(list2)
"""然后求list2中的素数就是答案"""
list3 = [p for p in list2 if 0 not in [p % d for d in range(2, int(sqrt(p)) + 1)]]
print(list3)
