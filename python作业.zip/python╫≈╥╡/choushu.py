from math import sqrt


# 把一个数的所有因子列出来，
def yinzhi(x):
    list_yinzhi = [1]
    for i in range(2, (x // 2) + 1):
        if x % i == 0:
            list_yinzhi.append(i)
    list_yinzhi.append(x)
    return list_yinzhi


# 判断是否是素数
def isss(x):
    if 0 not in [x % d for d in range(2, int(sqrt(x)) + 1)]:
        return 1
    else:
        return 0


def ss_yinzhi():
    list_anw = []

    for d in range(1, 100):
        list = yinzhi(d)
        listssyinzhi = []
        for i in list:
            if isss(i) == 1:
                listssyinzhi.append(i)
        if max(listssyinzhi) <= 5:
            list_anw.append(d)
    print(list_anw)


ss_yinzhi()